package com.tacticalarms;

import com.tacticalarms.entity.HeGrenadeEntity;
import com.tacticalarms.entity.SmokeGrenadeEntity;
import com.tacticalarms.item.AssaultRifleItem;
import com.tacticalarms.item.GrenadeItem;
import com.tacticalarms.item.RocketLauncherItem;
import com.tacticalarms.item.SniperRifleItem;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, ModMain.MODID);

    // ---- ammo ----
    public static final RegistryObject<Item> RIFLE_AMMO =
            ITEMS.register("rifle_ammo", () -> new Item(new Item.Properties().stacksTo(64)));
    public static final RegistryObject<Item> SNIPER_AMMO =
            ITEMS.register("sniper_ammo", () -> new Item(new Item.Properties().stacksTo(32)));
    public static final RegistryObject<Item> ROCKET =
            ITEMS.register("rocket", () -> new Item(new Item.Properties().stacksTo(8)));

    // ---- weapons ----
    public static final RegistryObject<Item> ASSAULT_RIFLE =
            ITEMS.register("assault_rifle", () -> new AssaultRifleItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> SNIPER_RIFLE =
            ITEMS.register("sniper_rifle", () -> new SniperRifleItem(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> ROCKET_LAUNCHER =
            ITEMS.register("rocket_launcher", () -> new RocketLauncherItem(new Item.Properties().stacksTo(1)));

    // ---- ordnance ----
    public static final RegistryObject<Item> GRENADE =
            ITEMS.register("grenade", () -> new GrenadeItem(new Item.Properties().stacksTo(16), HeGrenadeEntity::new));
    public static final RegistryObject<Item> SMOKE_GRENADE =
            ITEMS.register("smoke_grenade", () -> new GrenadeItem(new Item.Properties().stacksTo(16), SmokeGrenadeEntity::new));

    private ModItems() {}
}
