package com.tacticalarms;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/**
 * Custom sound events. assets/tacticalarms/sounds.json maps each one to a vanilla
 * sound by default, so the mod works with zero audio files. To use your own audio,
 * drop .ogg files into assets/tacticalarms/sounds/ and edit sounds.json.
 */
public final class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, ModMain.MODID);

    public static final RegistryObject<SoundEvent> RIFLE_SHOT = reg("rifle_shot");
    public static final RegistryObject<SoundEvent> SNIPER_SHOT = reg("sniper_shot");
    public static final RegistryObject<SoundEvent> ROCKET_LAUNCH = reg("rocket_launch");
    public static final RegistryObject<SoundEvent> GRENADE_THROW = reg("grenade_throw");
    public static final RegistryObject<SoundEvent> GRENADE_BOUNCE = reg("grenade_bounce");
    public static final RegistryObject<SoundEvent> SMOKE_POP = reg("smoke_pop");
    public static final RegistryObject<SoundEvent> GUN_EMPTY = reg("gun_empty");

    private static RegistryObject<SoundEvent> reg(String name) {
        return SOUNDS.register(name,
                () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(ModMain.MODID, name)));
    }

    private ModSounds() {}
}
