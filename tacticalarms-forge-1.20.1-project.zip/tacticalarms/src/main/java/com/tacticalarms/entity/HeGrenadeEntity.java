package com.tacticalarms.entity;

import com.tacticalarms.ArmsConfig;
import com.tacticalarms.ModEntities;
import com.tacticalarms.ModItems;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;

/** High-explosive grenade: bounces, then detonates when the fuse runs out. */
public class HeGrenadeEntity extends AbstractGrenadeEntity {

    public HeGrenadeEntity(EntityType<? extends HeGrenadeEntity> type, Level level) {
        super(type, level);
    }

    public HeGrenadeEntity(Level level, LivingEntity owner) {
        super(ModEntities.HE_GRENADE.get(), owner, level);
    }

    @Override
    protected Item getDefaultItem() {
        return ModItems.GRENADE.get();
    }

    @Override
    protected void clientTick() {
        if (tickCount % 3 == 0) {
            level().addParticle(ParticleTypes.SMOKE, getX(), getY() + 0.25D, getZ(), 0.0D, 0.02D, 0.0D);
        }
    }

    @Override
    protected void serverTick() {
        if (tickCount >= ArmsConfig.GRENADE_FUSE_TICKS.get()) {
            Explosions.detonate(this, ArmsConfig.GRENADE_POWER.get().floatValue());
            discard();
        }
    }
}
