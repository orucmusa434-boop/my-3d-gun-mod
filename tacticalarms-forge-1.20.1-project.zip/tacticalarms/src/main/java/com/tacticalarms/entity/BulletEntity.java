package com.tacticalarms.entity;

import com.tacticalarms.ModEntities;
import com.tacticalarms.ModItems;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;

/**
 * Lightweight bullet: no gravity, short lifetime, sweeps its path every tick (so even the
 * 9 blocks/tick sniper round cannot tunnel through entities). Rendered by BulletRenderer.
 */
public class BulletEntity extends ThrowableItemProjectile {
    private float damage = 4.0F;
    private float headshotMultiplier = 1.5F;
    private int maxLife = 40;

    public BulletEntity(EntityType<? extends BulletEntity> type, Level level) {
        super(type, level);
    }

    public BulletEntity(Level level, LivingEntity owner) {
        super(ModEntities.BULLET.get(), owner, level);
    }

    public void configure(float damage, float headshotMultiplier, int maxLifeTicks) {
        this.damage = damage;
        this.headshotMultiplier = headshotMultiplier;
        this.maxLife = maxLifeTicks;
    }

    @Override
    protected Item getDefaultItem() {
        return ModItems.RIFLE_AMMO.get();
    }

    @Override
    protected float getGravity() {
        return 0.0F;
    }

    @Override
    public void tick() {
        super.tick();
        if (!level().isClientSide && tickCount > maxLife) {
            discard();
        }
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        if (level().isClientSide) return;

        Entity target = result.getEntity();
        float dmg = damage;
        if (target instanceof LivingEntity && result.getLocation().y > target.getEyeY() - 0.2D) {
            dmg *= headshotMultiplier;
        }
        Entity owner = getOwner();
        target.invulnerableTime = 0; // allow full-auto fire to damage every bullet
        target.hurt(damageSources().thrown(this, owner == null ? this : owner), dmg);
        discard();
    }

    @Override
    protected void onHitBlock(BlockHitResult result) {
        super.onHitBlock(result);
        if (level() instanceof ServerLevel server) {
            BlockState state = level().getBlockState(result.getBlockPos());
            server.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, state),
                    result.getLocation().x, result.getLocation().y, result.getLocation().z,
                    3, 0.05D, 0.05D, 0.05D, 0.02D);
            discard();
        }
    }
}
