package com.tacticalarms.entity;

import com.tacticalarms.ArmsConfig;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;

/** Shared explosion + particle helper for rockets and HE grenades. */
final class Explosions {
    static void detonate(Entity source, float power) {
        if (!(source.level() instanceof ServerLevel level)) return;

        Level.ExplosionInteraction mode = ArmsConfig.BREAK_BLOCKS.get()
                ? Level.ExplosionInteraction.TNT
                : Level.ExplosionInteraction.NONE;

        double x = source.getX();
        double y = source.getY(0.5D);
        double z = source.getZ();

        level.explode(source, x, y, z, power, false, mode);
        // small, fixed particle budget on top of the vanilla explosion effect
        level.sendParticles(ParticleTypes.LARGE_SMOKE, x, y, z, 12, 0.5D, 0.4D, 0.5D, 0.03D);
        level.sendParticles(ParticleTypes.FLAME, x, y, z, 8, 0.3D, 0.3D, 0.3D, 0.08D);
    }

    private Explosions() {}
}
