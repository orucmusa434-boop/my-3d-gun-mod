package com.tacticalarms.entity;

import com.tacticalarms.ModSounds;
import net.minecraft.core.Direction;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

/**
 * Bouncing, timer-based grenade base. Ignores entities (passes through them), bounces off
 * blocks and comes to rest, after which it costs almost nothing to simulate.
 */
public abstract class AbstractGrenadeEntity extends ThrowableItemProjectile {

    protected AbstractGrenadeEntity(EntityType<? extends AbstractGrenadeEntity> type, Level level) {
        super(type, level);
    }

    protected AbstractGrenadeEntity(EntityType<? extends AbstractGrenadeEntity> type, LivingEntity owner, Level level) {
        super(type, owner, level);
    }

    @Override
    protected float getGravity() {
        return 0.04F;
    }

    @Override
    protected boolean canHitEntity(Entity entity) {
        return false;
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            clientTick();
        } else {
            serverTick();
        }
    }

    protected void clientTick() {
    }

    protected abstract void serverTick();

    @Override
    protected void onHitBlock(BlockHitResult hit) {
        super.onHitBlock(hit);

        Vec3 v = getDeltaMovement();
        Direction dir = hit.getDirection();
        Vec3 n = new Vec3(dir.getStepX(), dir.getStepY(), dir.getStepZ());

        // reflect and damp
        Vec3 r = v.subtract(n.scale(2.0D * v.dot(n))).scale(0.45D);

        if (dir == Direction.UP) {
            setPos(getX(), hit.getLocation().y, getZ());
            r = new Vec3(r.x * 0.6D, r.y, r.z * 0.6D);
            if (r.y < 0.06D) {
                r = new Vec3(r.x, 0.0D, r.z);
                if (r.horizontalDistanceSqr() < 0.0004D) {
                    r = Vec3.ZERO;
                    setNoGravity(true); // resting: stop colliding every tick
                }
            }
        }
        setDeltaMovement(r);

        if (!level().isClientSide && v.lengthSqr() > 0.04D) {
            level().playSound(null, getX(), getY(), getZ(),
                    ModSounds.GRENADE_BOUNCE.get(), SoundSource.NEUTRAL, 0.6F, 1.0F);
        }
    }
}
