package com.tacticalarms.entity;

import com.tacticalarms.ArmsConfig;
import com.tacticalarms.ModEntities;
import com.tacticalarms.ModItems;
import com.tacticalarms.ModSounds;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;

/**
 * Tactical smoke: pops shortly after being thrown, then emits a capped number of slow
 * smoke particles for a configurable time. Mobs standing in the cloud lose their target.
 */
public class SmokeGrenadeEntity extends AbstractGrenadeEntity {
    private static final int POP_DELAY_TICKS = 25;
    private int activeTicks = -1; // -1 = not popped yet

    public SmokeGrenadeEntity(EntityType<? extends SmokeGrenadeEntity> type, Level level) {
        super(type, level);
    }

    public SmokeGrenadeEntity(Level level, LivingEntity owner) {
        super(ModEntities.SMOKE_GRENADE.get(), owner, level);
    }

    @Override
    protected Item getDefaultItem() {
        return ModItems.SMOKE_GRENADE.get();
    }

    @Override
    protected void serverTick() {
        if (activeTicks < 0) {
            if (tickCount >= POP_DELAY_TICKS) {
                activeTicks = 0;
                level().playSound(null, getX(), getY(), getZ(),
                        ModSounds.SMOKE_POP.get(), SoundSource.NEUTRAL, 1.0F, 1.0F);
            }
            return;
        }

        activeTicks++;

        int count = ArmsConfig.SMOKE_PARTICLES_PER_BURST.get();
        if (count > 0 && activeTicks % 4 == 0 && level() instanceof ServerLevel server) {
            server.sendParticles(ParticleTypes.CAMPFIRE_COSY_SMOKE,
                    getX(), getY() + 0.3D, getZ(), count, 1.4D, 0.5D, 1.4D, 0.003D);
        }

        if (activeTicks % 10 == 0) {
            for (Mob mob : level().getEntitiesOfClass(Mob.class, getBoundingBox().inflate(4.0D, 2.5D, 4.0D))) {
                if (mob.getTarget() != null) {
                    mob.setTarget(null);
                }
            }
        }

        if (activeTicks >= ArmsConfig.SMOKE_DURATION_TICKS.get()) {
            discard();
        }
    }
}
