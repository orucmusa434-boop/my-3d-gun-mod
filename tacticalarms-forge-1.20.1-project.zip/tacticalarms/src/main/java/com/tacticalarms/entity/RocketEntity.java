package com.tacticalarms.entity;

import com.tacticalarms.ArmsConfig;
import com.tacticalarms.ModEntities;
import com.tacticalarms.ModItems;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

/** Straight-flying rocket: smoke + flame trail (client side), explodes on any impact or timeout. */
public class RocketEntity extends ThrowableItemProjectile {
    private static final int MAX_LIFE_TICKS = 160;

    public RocketEntity(EntityType<? extends RocketEntity> type, Level level) {
        super(type, level);
    }

    public RocketEntity(Level level, LivingEntity owner) {
        super(ModEntities.ROCKET.get(), owner, level);
    }

    @Override
    protected Item getDefaultItem() {
        return ModItems.ROCKET.get();
    }

    @Override
    protected float getGravity() {
        return 0.0F;
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            Vec3 v = getDeltaMovement();
            double tx = getX() - v.x * 0.6D;
            double ty = getY() + 0.1D - v.y * 0.6D;
            double tz = getZ() - v.z * 0.6D;
            level().addParticle(ParticleTypes.SMOKE, tx, ty, tz, 0.0D, 0.0D, 0.0D);
            level().addParticle(ParticleTypes.FLAME, tx, ty, tz, 0.0D, 0.0D, 0.0D);
        } else if (tickCount > MAX_LIFE_TICKS) {
            explode();
        }
    }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        if (!level().isClientSide) {
            explode();
        }
    }

    private void explode() {
        Explosions.detonate(this, ArmsConfig.ROCKET_POWER.get().floatValue());
        discard();
    }
}
