package com.tacticalarms.network;

import com.tacticalarms.client.ClientHooks;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/** Server -> client: kick the camera upward (and a little sideways). */
public class RecoilPacket {
    private final float pitch;
    private final float yaw;

    public RecoilPacket(float pitch, float yaw) {
        this.pitch = pitch;
        this.yaw = yaw;
    }

    public static void encode(RecoilPacket msg, FriendlyByteBuf buf) {
        buf.writeFloat(msg.pitch);
        buf.writeFloat(msg.yaw);
    }

    public static RecoilPacket decode(FriendlyByteBuf buf) {
        return new RecoilPacket(buf.readFloat(), buf.readFloat());
    }

    public static void handle(RecoilPacket msg, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> ClientHooks.applyRecoil(msg.pitch, msg.yaw)));
        c.setPacketHandled(true);
    }
}
