package com.tacticalarms.network;

import com.tacticalarms.ModMain;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.Optional;

public final class Network {
    private static final String PROTOCOL = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(ModMain.MODID, "main"),
            () -> PROTOCOL, PROTOCOL::equals, PROTOCOL::equals);

    public static void register() {
        CHANNEL.registerMessage(0, RecoilPacket.class,
                RecoilPacket::encode, RecoilPacket::decode, RecoilPacket::handle,
                Optional.of(NetworkDirection.PLAY_TO_CLIENT));
    }

    private Network() {}
}
