package com.tacticalarms.client;

import com.tacticalarms.ModEntities;
import com.tacticalarms.ModMain;
import net.minecraft.client.renderer.entity.ThrownItemRenderer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ModMain.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientSetup {

    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        // hand-built tracer and rocket meshes (a handful of quads each, no baked models)
        event.registerEntityRenderer(ModEntities.BULLET.get(), BulletRenderer::new);
        event.registerEntityRenderer(ModEntities.ROCKET.get(), RocketRenderer::new);

        // grenades reuse their low-poly item models, drawn as a single billboarded item
        event.registerEntityRenderer(ModEntities.HE_GRENADE.get(),
                ctx -> new ThrownItemRenderer<>(ctx, 0.8F, false));
        event.registerEntityRenderer(ModEntities.SMOKE_GRENADE.get(),
                ctx -> new ThrownItemRenderer<>(ctx, 0.8F, false));
    }

    private ClientSetup() {}
}
