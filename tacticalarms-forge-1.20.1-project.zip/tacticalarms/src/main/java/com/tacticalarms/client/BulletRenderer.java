package com.tacticalarms.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.tacticalarms.ModMain;
import com.tacticalarms.entity.BulletEntity;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * Bullet tracer: two crossed quads (8 vertices total) with a hot-to-warm colour gradient.
 * Full-bright, so there is no per-bullet light lookup either.
 */
public class BulletRenderer extends EntityRenderer<BulletEntity> {
    private static final ResourceLocation WHITE =
            new ResourceLocation(ModMain.MODID, "textures/entity/white.png");

    private static final float TAIL = -0.9F;
    private static final float HEAD = 0.15F;
    private static final float HALF_WIDTH = 0.018F;

    public BulletRenderer(EntityRendererProvider.Context context) {
        super(context);
    }

    @Override
    public void render(BulletEntity bullet, float entityYaw, float partialTick,
                       PoseStack poseStack, MultiBufferSource buffer, int packedLight) {
        poseStack.pushPose();
        poseStack.mulPose(Axis.YP.rotationDegrees(Mth.lerp(partialTick, bullet.yRotO, bullet.getYRot()) - 90.0F));
        poseStack.mulPose(Axis.ZP.rotationDegrees(Mth.lerp(partialTick, bullet.xRotO, bullet.getXRot())));

        VertexConsumer vc = buffer.getBuffer(RenderType.entityCutoutNoCull(WHITE));
        PoseStack.Pose pose = poseStack.last();
        int light = LightTexture.FULL_BRIGHT;

        // quad in the XY plane
        vertex(vc, pose, TAIL, -HALF_WIDTH, 0.0F, 255, 120, 30, light);
        vertex(vc, pose, HEAD, -HALF_WIDTH, 0.0F, 255, 245, 190, light);
        vertex(vc, pose, HEAD, HALF_WIDTH, 0.0F, 255, 245, 190, light);
        vertex(vc, pose, TAIL, HALF_WIDTH, 0.0F, 255, 120, 30, light);
        // quad in the XZ plane
        vertex(vc, pose, TAIL, 0.0F, -HALF_WIDTH, 255, 120, 30, light);
        vertex(vc, pose, HEAD, 0.0F, -HALF_WIDTH, 255, 245, 190, light);
        vertex(vc, pose, HEAD, 0.0F, HALF_WIDTH, 255, 245, 190, light);
        vertex(vc, pose, TAIL, 0.0F, HALF_WIDTH, 255, 120, 30, light);

        poseStack.popPose();
    }

    private static void vertex(VertexConsumer vc, PoseStack.Pose pose, float x, float y, float z,
                               int r, int g, int b, int light) {
        vc.vertex(pose.pose(), x, y, z)
                .color(r, g, b, 255)
                .uv(0.5F, 0.5F)
                .overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(light)
                .normal(pose.normal(), 0.0F, 1.0F, 0.0F)
                .endVertex();
    }

    @Override
    public ResourceLocation getTextureLocation(BulletEntity bullet) {
        return WHITE;
    }
}
