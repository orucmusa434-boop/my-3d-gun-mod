package com.tacticalarms.client;

import com.tacticalarms.ModMain;
import com.tacticalarms.item.SniperRifleItem;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ComputeFovModifierEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Scope zoom: crouch while holding the sniper rifle. */
@Mod.EventBusSubscriber(modid = ModMain.MODID, value = Dist.CLIENT)
public final class ClientEvents {

    @SubscribeEvent
    public static void onFov(ComputeFovModifierEvent event) {
        Player player = event.getPlayer();
        if (player.isCrouching() && player.getMainHandItem().getItem() instanceof SniperRifleItem) {
            event.setNewFovModifier(event.getFovModifier() * 0.25F);
        }
    }

    private ClientEvents() {}
}
