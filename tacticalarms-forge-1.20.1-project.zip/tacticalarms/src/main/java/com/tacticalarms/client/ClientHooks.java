package com.tacticalarms.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.util.Mth;

/** Only ever referenced from client-side code paths (see RecoilPacket). */
public final class ClientHooks {

    public static void applyRecoil(float pitchKick, float yawKick) {
        LocalPlayer player = Minecraft.getInstance().player;
        if (player == null) return;
        player.setXRot(Mth.clamp(player.getXRot() - pitchKick, -90.0F, 90.0F));
        player.setYRot(player.getYRot() + yawKick);
    }

    private ClientHooks() {}
}
