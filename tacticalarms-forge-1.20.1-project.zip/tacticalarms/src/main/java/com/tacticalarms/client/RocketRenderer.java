package com.tacticalarms.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import com.tacticalarms.ModMain;
import com.tacticalarms.entity.RocketEntity;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/**
 * Low-poly rocket built from 4 boxes (body, warhead, two crossed fins) = 24 quads,
 * coloured per vertex from a single 1-colour texture. Lit with the world light at its position.
 */
public class RocketRenderer extends EntityRenderer<RocketEntity> {
    private static final ResourceLocation WHITE =
            new ResourceLocation(ModMain.MODID, "textures/entity/white.png");

    public RocketRenderer(EntityRendererProvider.Context context) {
        super(context);
    }

    @Override
    public void render(RocketEntity rocket, float entityYaw, float partialTick,
                       PoseStack poseStack, MultiBufferSource buffer, int packedLight) {
        poseStack.pushPose();
        poseStack.mulPose(Axis.YP.rotationDegrees(Mth.lerp(partialTick, rocket.yRotO, rocket.getYRot()) - 90.0F));
        poseStack.mulPose(Axis.ZP.rotationDegrees(Mth.lerp(partialTick, rocket.xRotO, rocket.getXRot())));

        VertexConsumer vc = buffer.getBuffer(RenderType.entityCutoutNoCull(WHITE));
        PoseStack.Pose pose = poseStack.last();

        // body (olive)
        box(vc, pose, packedLight, -0.40F, -0.07F, -0.07F, 0.22F, 0.07F, 0.07F, 90, 100, 70);
        // warhead (red)
        box(vc, pose, packedLight, 0.22F, -0.05F, -0.05F, 0.38F, 0.05F, 0.05F, 200, 50, 40);
        // fins (dark grey), vertical + horizontal
        box(vc, pose, packedLight, -0.40F, -0.17F, -0.012F, -0.24F, 0.17F, 0.012F, 60, 60, 66);
        box(vc, pose, packedLight, -0.40F, -0.012F, -0.17F, -0.24F, 0.012F, 0.17F, 60, 60, 66);

        poseStack.popPose();
    }

    private static void box(VertexConsumer vc, PoseStack.Pose pose, int light,
                            float x0, float y0, float z0, float x1, float y1, float z1,
                            int r, int g, int b) {
        // +Y
        quad(vc, pose, light, r, g, b, 0, 1, 0, x0, y1, z0, x0, y1, z1, x1, y1, z1, x1, y1, z0);
        // -Y
        quad(vc, pose, light, r, g, b, 0, -1, 0, x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1);
        // +X
        quad(vc, pose, light, r, g, b, 1, 0, 0, x1, y0, z0, x1, y1, z0, x1, y1, z1, x1, y0, z1);
        // -X
        quad(vc, pose, light, r, g, b, -1, 0, 0, x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0);
        // +Z
        quad(vc, pose, light, r, g, b, 0, 0, 1, x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1);
        // -Z
        quad(vc, pose, light, r, g, b, 0, 0, -1, x0, y0, z0, x0, y1, z0, x1, y1, z0, x1, y0, z0);
    }

    private static void quad(VertexConsumer vc, PoseStack.Pose pose, int light, int r, int g, int b,
                             float nx, float ny, float nz,
                             float ax, float ay, float az, float bx, float by, float bz,
                             float cx, float cy, float cz, float dx, float dy, float dz) {
        v(vc, pose, light, r, g, b, nx, ny, nz, ax, ay, az);
        v(vc, pose, light, r, g, b, nx, ny, nz, bx, by, bz);
        v(vc, pose, light, r, g, b, nx, ny, nz, cx, cy, cz);
        v(vc, pose, light, r, g, b, nx, ny, nz, dx, dy, dz);
    }

    private static void v(VertexConsumer vc, PoseStack.Pose pose, int light, int r, int g, int b,
                          float nx, float ny, float nz, float x, float y, float z) {
        vc.vertex(pose.pose(), x, y, z)
                .color(r, g, b, 255)
                .uv(0.5F, 0.5F)
                .overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(light)
                .normal(pose.normal(), nx, ny, nz)
                .endVertex();
    }

    @Override
    public ResourceLocation getTextureLocation(RocketEntity rocket) {
        return WHITE;
    }
}
