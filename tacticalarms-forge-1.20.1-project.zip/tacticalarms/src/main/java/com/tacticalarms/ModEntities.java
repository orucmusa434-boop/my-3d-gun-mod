package com.tacticalarms;

import com.tacticalarms.entity.BulletEntity;
import com.tacticalarms.entity.HeGrenadeEntity;
import com.tacticalarms.entity.RocketEntity;
import com.tacticalarms.entity.SmokeGrenadeEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, ModMain.MODID);

    // Clients simulate projectile movement themselves, so a slow update interval is enough
    // (saves network bandwidth and CPU on weak devices).
    public static final RegistryObject<EntityType<BulletEntity>> BULLET = ENTITIES.register("bullet",
            () -> EntityType.Builder.<BulletEntity>of(BulletEntity::new, MobCategory.MISC)
                    .sized(0.15F, 0.15F).clientTrackingRange(10).updateInterval(10).fireImmune()
                    .build("bullet"));

    public static final RegistryObject<EntityType<RocketEntity>> ROCKET = ENTITIES.register("rocket",
            () -> EntityType.Builder.<RocketEntity>of(RocketEntity::new, MobCategory.MISC)
                    .sized(0.25F, 0.25F).clientTrackingRange(10).updateInterval(5).fireImmune()
                    .build("rocket"));

    public static final RegistryObject<EntityType<HeGrenadeEntity>> HE_GRENADE = ENTITIES.register("he_grenade",
            () -> EntityType.Builder.<HeGrenadeEntity>of(HeGrenadeEntity::new, MobCategory.MISC)
                    .sized(0.25F, 0.25F).clientTrackingRange(8).updateInterval(5)
                    .build("he_grenade"));

    public static final RegistryObject<EntityType<SmokeGrenadeEntity>> SMOKE_GRENADE = ENTITIES.register("smoke_grenade",
            () -> EntityType.Builder.<SmokeGrenadeEntity>of(SmokeGrenadeEntity::new, MobCategory.MISC)
                    .sized(0.25F, 0.25F).clientTrackingRange(8).updateInterval(5)
                    .build("smoke_grenade"));

    private ModEntities() {}
}
