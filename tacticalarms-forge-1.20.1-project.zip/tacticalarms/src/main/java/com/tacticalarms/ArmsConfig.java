package com.tacticalarms;

import net.minecraftforge.common.ForgeConfigSpec;

/** Tiny common config: config/tacticalarms-common.toml */
public final class ArmsConfig {
    public static final ForgeConfigSpec SPEC;

    public static final ForgeConfigSpec.DoubleValue RIFLE_DAMAGE;
    public static final ForgeConfigSpec.DoubleValue SNIPER_DAMAGE;

    public static final ForgeConfigSpec.BooleanValue BREAK_BLOCKS;
    public static final ForgeConfigSpec.DoubleValue ROCKET_POWER;
    public static final ForgeConfigSpec.DoubleValue GRENADE_POWER;
    public static final ForgeConfigSpec.IntValue GRENADE_FUSE_TICKS;

    public static final ForgeConfigSpec.IntValue SMOKE_DURATION_TICKS;
    public static final ForgeConfigSpec.IntValue SMOKE_PARTICLES_PER_BURST;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();

        b.push("weapons");
        RIFLE_DAMAGE = b.comment("Assault rifle bullet damage (2.0 = 1 heart)")
                .defineInRange("rifleDamage", 4.0D, 0.5D, 100.0D);
        SNIPER_DAMAGE = b.comment("Sniper bullet damage (headshots are x2)")
                .defineInRange("sniperDamage", 22.0D, 0.5D, 200.0D);
        b.pop();

        b.push("explosives");
        BREAK_BLOCKS = b.comment("Rockets and grenades destroy blocks")
                .define("breakBlocks", true);
        ROCKET_POWER = b.comment("Rocket explosion power (TNT = 4.0)")
                .defineInRange("rocketPower", 3.0D, 0.5D, 10.0D);
        GRENADE_POWER = b.comment("HE grenade explosion power")
                .defineInRange("grenadePower", 2.5D, 0.5D, 10.0D);
        GRENADE_FUSE_TICKS = b.comment("HE grenade fuse in ticks (20 = 1 second)")
                .defineInRange("grenadeFuseTicks", 60, 10, 200);
        b.pop();

        b.push("performance");
        SMOKE_DURATION_TICKS = b.comment("How long a smoke grenade emits smoke (ticks)")
                .defineInRange("smokeDurationTicks", 200, 40, 1200);
        SMOKE_PARTICLES_PER_BURST = b.comment("Smoke particles per burst (one burst every 4 ticks). Lower = faster on phones")
                .defineInRange("smokeParticlesPerBurst", 3, 0, 12);
        b.pop();

        SPEC = b.build();
    }

    private ArmsConfig() {}
}
