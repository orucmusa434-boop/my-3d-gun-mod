package com.tacticalarms.item;

import com.tacticalarms.ArmsConfig;
import com.tacticalarms.ModItems;
import com.tacticalarms.ModSounds;
import com.tacticalarms.entity.BulletEntity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** Single shot, heavy damage, very fast bullet. Crouch = scope zoom + perfect accuracy. */
public class SniperRifleItem extends GunItem {
    private static final int COOLDOWN_TICKS = 40;
    private static final float MUZZLE_VELOCITY = 9.0F;

    public SniperRifleItem(Properties properties) {
        super(properties, ModItems.SNIPER_AMMO);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!hasAmmo(player)) {
            dryFire(level, player);
            return InteractionResultHolder.fail(stack);
        }

        if (!level.isClientSide && player instanceof ServerPlayer sp) {
            consumeAmmo(player);

            BulletEntity bullet = new BulletEntity(level, player);
            bullet.configure(ArmsConfig.SNIPER_DAMAGE.get().floatValue(), 2.0F, 60);
            float spread = player.isCrouching() ? 0.0F : 2.5F;
            bullet.shootFromRotation(player, player.getXRot(), player.getYRot(), 0.0F, MUZZLE_VELOCITY, spread);
            level.addFreshEntity(bullet);

            level.playSound(null, player.getX(), player.getY(), player.getZ(),
                    ModSounds.SNIPER_SHOT.get(), SoundSource.PLAYERS, 1.6F, 1.0F);
            muzzleFx(sp, 1.1D, 4, true);
            recoil(sp, 3.5F, 0.6F);
        }

        player.getCooldowns().addCooldown(this, COOLDOWN_TICKS);
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }
}
