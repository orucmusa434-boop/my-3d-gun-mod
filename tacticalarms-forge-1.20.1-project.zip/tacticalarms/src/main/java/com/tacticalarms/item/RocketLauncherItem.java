package com.tacticalarms.item;

import com.tacticalarms.ModItems;
import com.tacticalarms.ModSounds;
import com.tacticalarms.entity.RocketEntity;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Fires an exploding rocket with a smoke trail. Back-blast smoke puffs out behind you. */
public class RocketLauncherItem extends GunItem {
    private static final int COOLDOWN_TICKS = 50;
    private static final float ROCKET_VELOCITY = 1.8F;

    public RocketLauncherItem(Properties properties) {
        super(properties, ModItems.ROCKET);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!hasAmmo(player)) {
            dryFire(level, player);
            return InteractionResultHolder.fail(stack);
        }

        if (!level.isClientSide && player instanceof ServerPlayer sp) {
            consumeAmmo(player);

            RocketEntity rocket = new RocketEntity(level, player);
            rocket.shootFromRotation(player, player.getXRot(), player.getYRot(), 0.0F, ROCKET_VELOCITY, 0.4F);
            level.addFreshEntity(rocket);

            level.playSound(null, player.getX(), player.getY(), player.getZ(),
                    ModSounds.ROCKET_LAUNCH.get(), SoundSource.PLAYERS, 1.4F, 1.0F);

            // back-blast
            Vec3 back = player.getLookAngle().scale(-1.2D);
            Vec3 p = player.getEyePosition().add(back).add(0.0D, -0.3D, 0.0D);
            ((ServerLevel) level).sendParticles(ParticleTypes.LARGE_SMOKE, p.x, p.y, p.z, 6, 0.2D, 0.15D, 0.2D, 0.03D);

            recoil(sp, 5.0F, 1.0F);
        }

        player.getCooldowns().addCooldown(this, COOLDOWN_TICKS);
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }
}
