package com.tacticalarms.item;

import com.tacticalarms.ModSounds;
import com.tacticalarms.entity.AbstractGrenadeEntity;
import net.minecraft.sounds.SoundSource;
import net.minecraft.stats.Stats;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

import java.util.function.BiFunction;

/** One class for both HE and smoke grenades; the entity factory decides which one is thrown. */
public class GrenadeItem extends Item {
    private final BiFunction<Level, LivingEntity, ? extends AbstractGrenadeEntity> factory;

    public GrenadeItem(Properties properties, BiFunction<Level, LivingEntity, ? extends AbstractGrenadeEntity> factory) {
        super(properties);
        this.factory = factory;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                ModSounds.GRENADE_THROW.get(), SoundSource.PLAYERS, 0.8F, 0.9F + level.random.nextFloat() * 0.2F);

        if (!level.isClientSide) {
            AbstractGrenadeEntity grenade = factory.apply(level, player);
            // negative third value lobs the grenade slightly upward
            grenade.shootFromRotation(player, player.getXRot(), player.getYRot(), -8.0F, 1.1F, 0.4F);
            level.addFreshEntity(grenade);
        }

        player.awardStat(Stats.ITEM_USED.get(this));
        if (!player.getAbilities().instabuild) {
            stack.shrink(1);
        }
        player.getCooldowns().addCooldown(this, 20);
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }
}
