package com.tacticalarms.item;

import com.tacticalarms.ModSounds;
import com.tacticalarms.network.Network;
import com.tacticalarms.network.RecoilPacket;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.PacketDistributor;

import java.util.function.Supplier;

/** Shared helpers: ammo lookup/consumption, muzzle effects, recoil. */
public abstract class GunItem extends Item {
    private final Supplier<? extends Item> ammo;

    protected GunItem(Properties properties, Supplier<? extends Item> ammo) {
        super(properties);
        this.ammo = ammo;
    }

    protected boolean hasAmmo(Player player) {
        return player.getAbilities().instabuild || !findAmmo(player).isEmpty();
    }

    /** Removes one round. Creative players never run out. */
    protected boolean consumeAmmo(Player player) {
        if (player.getAbilities().instabuild) return true;
        ItemStack stack = findAmmo(player);
        if (stack.isEmpty()) return false;
        stack.shrink(1);
        return true;
    }

    private ItemStack findAmmo(Player player) {
        Inventory inv = player.getInventory();
        Item wanted = ammo.get();
        ItemStack off = inv.offhand.get(0);
        if (off.is(wanted)) return off;
        for (ItemStack s : inv.items) {
            if (s.is(wanted)) return s;
        }
        return ItemStack.EMPTY;
    }

    protected static void dryFire(Level level, Player player) {
        if (!level.isClientSide) {
            level.playSound(null, player.getX(), player.getY(), player.getZ(),
                    ModSounds.GUN_EMPTY.get(), SoundSource.PLAYERS, 0.7F, 1.0F);
        }
    }

    protected static void muzzleFx(ServerPlayer player, double forward, int smoke, boolean flame) {
        Vec3 look = player.getLookAngle();
        Vec3 p = player.getEyePosition().add(look.scale(forward)).add(0.0D, -0.12D, 0.0D);
        ServerLevel level = (ServerLevel) player.level();
        level.sendParticles(ParticleTypes.SMOKE, p.x, p.y, p.z, smoke, 0.02D, 0.02D, 0.02D, 0.01D);
        if (flame) {
            level.sendParticles(ParticleTypes.FLAME, p.x, p.y, p.z, 1, 0.0D, 0.0D, 0.0D, 0.01D);
        }
    }

    protected static void recoil(ServerPlayer player, float pitchKick, float yawRange) {
        float yaw = (player.getRandom().nextFloat() - 0.5F) * yawRange;
        Network.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new RecoilPacket(pitchKick, yaw));
    }
}
