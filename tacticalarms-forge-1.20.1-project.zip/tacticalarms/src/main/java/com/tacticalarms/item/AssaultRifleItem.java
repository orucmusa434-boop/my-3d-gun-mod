package com.tacticalarms.item;

import com.tacticalarms.ArmsConfig;
import com.tacticalarms.ModItems;
import com.tacticalarms.ModSounds;
import com.tacticalarms.entity.BulletEntity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;

/** Full-auto: hold right-click. Fires every FIRE_INTERVAL ticks (2 = 600 rpm). */
public class AssaultRifleItem extends GunItem {
    private static final int FIRE_INTERVAL = 2;
    private static final float MUZZLE_VELOCITY = 4.0F;
    private static final float SPREAD = 1.6F;

    public AssaultRifleItem(Properties properties) {
        super(properties, ModItems.RIFLE_AMMO);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!hasAmmo(player)) {
            dryFire(level, player);
            return InteractionResultHolder.fail(stack);
        }
        player.startUsingItem(hand);
        return InteractionResultHolder.consume(stack);
    }

    @Override
    public void onUseTick(Level level, LivingEntity entity, ItemStack stack, int remaining) {
        if (level.isClientSide || !(entity instanceof ServerPlayer player)) return;

        int held = getUseDuration(stack) - remaining;
        if (held % FIRE_INTERVAL != 0) return;

        if (!consumeAmmo(player)) {
            dryFire(level, player);
            player.stopUsingItem();
            return;
        }

        BulletEntity bullet = new BulletEntity(level, player);
        bullet.configure(ArmsConfig.RIFLE_DAMAGE.get().floatValue(), 1.5F, 40);
        float spread = player.isCrouching() ? SPREAD * 0.5F : SPREAD;
        bullet.shootFromRotation(player, player.getXRot(), player.getYRot(), 0.0F, MUZZLE_VELOCITY, spread);
        level.addFreshEntity(bullet);

        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                ModSounds.RIFLE_SHOT.get(), SoundSource.PLAYERS, 0.9F, 0.95F + level.random.nextFloat() * 0.1F);
        muzzleFx(player, 0.9D, 1, true);
        recoil(player, 0.8F, 0.5F);
    }

    @Override
    public int getUseDuration(ItemStack stack) {
        return 72000;
    }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return UseAnim.NONE;
    }
}
