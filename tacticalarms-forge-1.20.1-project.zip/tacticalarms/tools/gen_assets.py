#!/usr/bin/env python3
"""Generates every non-Java asset (no dependencies). Run from the project root:
    python3 tools/gen_assets.py
Edit the PARTS tables below to reshape the low-poly weapon models."""
import json, os, random, struct, zlib

MOD = "tacticalarms"
ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main")
ASSETS = os.path.join(ROOT, "resources", "assets", MOD)
DATA = os.path.join(ROOT, "resources", "data", MOD)


def write(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)


def write_json(path, obj):
    write(path, json.dumps(obj, indent=2) + "\n")


# ---------------------------------------------------------------- PNG writer
def write_png(path, rows):
    h, w = len(rows), len(rows[0])
    raw = b"".join(b"\x00" + b"".join(struct.pack("BBBB", *px) for px in row) for row in rows)

    def chunk(tag, data):
        c = struct.pack(">I", len(data)) + tag + data
        return c + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)

    png = b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0)) \
        + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b"")
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as f:
        f.write(png)


def palette_texture(name, colors, seed):
    """16x16 texture split into 4 colour quadrants (dark / metal / grip / accent) with light noise."""
    rnd = random.Random(seed)
    rows = []
    for y in range(16):
        row = []
        for x in range(16):
            q = (1 if x >= 8 else 0) + (2 if y >= 8 else 0)
            r, g, b = colors[q]
            n = rnd.randint(-7, 7)
            row.append((max(0, min(255, r + n)), max(0, min(255, g + n)), max(0, min(255, b + n)), 255))
        rows.append(row)
    write_png(os.path.join(ASSETS, "textures", "item", name + ".png"), rows)


REGION = {"dark": [0, 0, 8, 8], "metal": [8, 0, 16, 8], "grip": [0, 8, 8, 16], "accent": [8, 8, 16, 16]}


def element(frm, to, region):
    uv = REGION[region]
    return {
        "from": frm, "to": to,
        "faces": {f: {"uv": uv, "texture": "#0"} for f in ("north", "east", "south", "west", "up", "down")},
    }


def model(name, parts, display, gui_light="front"):
    tex = "%s:item/%s" % (MOD, name)
    write_json(os.path.join(ASSETS, "models", "item", name + ".json"), {
        "textures": {"0": tex, "particle": tex},
        "elements": [element(*p) for p in parts],
        "display": display,
        "gui_light": gui_light,
    })


def gun_display(fp=(0, 3, 2), tp=(0, 3.5, 1.5), s=0.8):
    # Barrel points along +X in the model; rotating -90 deg about Y points it away from the player.
    return {
        "gui": {"rotation": [0, 0, 0], "translation": [0, 0, 0], "scale": [0.95, 0.95, 0.95]},
        "ground": {"rotation": [0, 0, 0], "translation": [0, 3, 0], "scale": [0.5, 0.5, 0.5]},
        "fixed": {"rotation": [0, 0, 0], "translation": [0, 0, 0], "scale": [0.9, 0.9, 0.9]},
        "thirdperson_righthand": {"rotation": [0, -90, 0], "translation": list(tp), "scale": [s, s, s]},
        "thirdperson_lefthand": {"rotation": [0, 90, 0], "translation": list(tp), "scale": [s, s, s]},
        "firstperson_righthand": {"rotation": [0, -90, 0], "translation": list(fp), "scale": [s, s, s]},
        "firstperson_lefthand": {"rotation": [0, 90, 0], "translation": list(fp), "scale": [s, s, s]},
    }


def grenade_display():
    return {
        "gui": {"rotation": [30, 225, 0], "translation": [0, -1, 0], "scale": [1.6, 1.6, 1.6]},
        "ground": {"rotation": [0, 0, 0], "translation": [0, 2, 0], "scale": [0.9, 0.9, 0.9]},
        "fixed": {"rotation": [0, 180, 0], "translation": [0, 0, 0], "scale": [1.4, 1.4, 1.4]},
        "thirdperson_righthand": {"rotation": [0, 0, 0], "translation": [0, 3, 1], "scale": [0.8, 0.8, 0.8]},
        "thirdperson_lefthand": {"rotation": [0, 0, 0], "translation": [0, 3, 1], "scale": [0.8, 0.8, 0.8]},
        "firstperson_righthand": {"rotation": [0, -20, 0], "translation": [1, 2, 0], "scale": [0.9, 0.9, 0.9]},
        "firstperson_lefthand": {"rotation": [0, 20, 0], "translation": [-1, 2, 0], "scale": [0.9, 0.9, 0.9]},
    }


# ------------------------------------------------------------ weapon models
# each part: (from[x,y,z], to[x,y,z], region)   coordinates 0..16, barrel toward +X
ASSAULT = [
    ([3, 6, 7], [11, 9, 9], "metal"),            # receiver
    ([11, 6.5, 7.2], [14, 8.8, 8.8], "dark"),    # handguard
    ([14, 7.3, 7.6], [16, 8.3, 8.4], "metal"),   # barrel
    ([0, 5, 7.2], [3, 8.5, 8.8], "grip"),        # stock
    ([6, 3.5, 7.2], [7.8, 6, 8.8], "grip"),      # pistol grip
    ([8.5, 2.5, 7.3], [10.5, 6, 8.7], "dark"),   # magazine
    ([3.5, 9, 7.6], [4.5, 10, 8.4], "dark"),     # rear sight
    ([12.5, 8.8, 7.7], [13.3, 10, 8.3], "dark"), # front sight
    ([7, 7, 8.9], [9, 8.5, 9.05], "accent"),     # ejection port
]
SNIPER = [
    ([0, 4.5, 7.3], [4, 8.5, 8.7], "grip"),        # stock
    ([4, 6, 7.2], [9, 9, 8.8], "dark"),            # receiver
    ([9, 7, 7.6], [16, 8.4, 8.4], "metal"),        # long barrel
    ([15, 6.6, 7.3], [16, 8.8, 8.7], "dark"),      # muzzle brake
    ([4.5, 9.2, 7.4], [10.5, 10.8, 8.6], "dark"),  # scope tube
    ([10.5, 9, 7.2], [11.5, 11, 8.8], "accent"),   # front lens
    ([3.5, 9, 7.2], [4.5, 11, 8.8], "accent"),     # rear lens
    ([5.5, 9, 7.6], [6.2, 9.4, 8.4], "metal"),     # scope mount
    ([5.5, 3.5, 7.4], [7, 6, 8.6], "grip"),        # grip
    ([7, 4.5, 7.4], [8.5, 6, 8.6], "dark"),        # magazine
    ([12, 5.5, 7.0], [12.6, 7, 7.4], "metal"),     # bipod leg
    ([12, 5.5, 8.6], [12.6, 7, 9.0], "metal"),     # bipod leg
    ([6.5, 7.5, 8.8], [7.2, 8.2, 10], "accent"),   # bolt handle
]
ROCKET = [
    ([1, 6, 6], [14, 10, 10], "metal"),         # launch tube
    ([0, 5.5, 5.5], [1, 10.5, 10.5], "dark"),   # rear flare
    ([14, 5.5, 5.5], [16, 10.5, 10.5], "dark"), # muzzle
    ([15.5, 6.5, 6.5], [16, 9.5, 9.5], "accent"),  # warhead tip
    ([6, 3, 7.2], [8, 6, 8.8], "grip"),         # grip
    ([11, 3.5, 7.2], [12.5, 6, 8.8], "grip"),   # front grip
    ([6, 10, 7.6], [9, 11.5, 8.4], "dark"),     # sight
    ([8, 11.5, 7.8], [9, 13, 8.2], "dark"),     # sight post
    ([2, 4, 7], [4, 6, 9], "dark"),             # shoulder rest
    ([8, 5.9, 5.9], [9.2, 10.1, 10.1], "accent"),  # band
]
GRENADE = [
    ([6, 3, 6], [10, 9, 10], "metal"),            # body
    ([5.8, 5, 5.8], [10.2, 6, 10.2], "dark"),     # band
    ([6.5, 9, 6.5], [9.5, 10, 9.5], "dark"),      # neck
    ([7, 10, 7], [9, 11, 9], "grip"),             # fuse cap
    ([9.3, 5, 7.4], [10.1, 10.5, 8.6], "grip"),   # spoon lever
    ([7.5, 11, 6], [8.5, 12, 7], "accent"),       # pin ring
]
SMOKE = [
    ([6.5, 2, 6.5], [9.5, 10, 9.5], "metal"),     # canister
    ([6.3, 3, 6.3], [9.7, 4, 9.7], "accent"),     # band low
    ([6.3, 8, 6.3], [9.7, 9, 9.7], "accent"),     # band high
    ([7, 10, 7], [9, 11, 9], "dark"),             # top
    ([7.5, 11, 7.5], [8.5, 12, 8.5], "grip"),     # fuse
    ([9.4, 6, 7.5], [10.2, 11, 8.5], "grip"),     # spoon lever
]


def build_models():
    model("assault_rifle", ASSAULT, gun_display())
    model("sniper_rifle", SNIPER, gun_display(s=0.85))
    model("rocket_launcher", ROCKET, gun_display(fp=(0, 3, 3), tp=(0, 3.5, 2), s=0.8))
    model("grenade", GRENADE, grenade_display())
    model("smoke_grenade", SMOKE, grenade_display())

    palette_texture("assault_rifle", [(40, 42, 46), (88, 92, 98), (70, 78, 52), (180, 150, 40)], 1)
    palette_texture("sniper_rifle", [(30, 30, 34), (70, 74, 80), (96, 66, 40), (60, 140, 190)], 2)
    palette_texture("rocket_launcher", [(50, 54, 44), (84, 96, 64), (40, 40, 40), (190, 50, 30)], 3)
    palette_texture("grenade", [(50, 70, 40), (72, 98, 56), (150, 150, 150), (200, 180, 60)], 4)
    palette_texture("smoke_grenade", [(90, 90, 95), (150, 152, 158), (60, 60, 64), (200, 60, 50)], 5)


# --------------------------------------------------------------- ammo sprites
def blank():
    return [[(0, 0, 0, 0) for _ in range(16)] for _ in range(16)]


def rect(img, x0, y0, x1, y1, color):
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            img[y][x] = color + (255,)


def build_ammo():
    brass, copper, dark, steel, red = (205, 165, 55), (190, 105, 60), (60, 60, 66), (150, 152, 160), (200, 45, 35)

    rifle = blank()
    for x in (3, 7, 11):
        rect(rifle, x, 7, x + 2, 13, brass)
        rect(rifle, x, 4, x + 2, 6, copper)
        rect(rifle, x + 1, 3, x + 1, 3, copper)
    rect(rifle, 2, 14, 13, 14, dark)
    write_png(os.path.join(ASSETS, "textures", "item", "rifle_ammo.png"), rifle)

    sniper = blank()
    rect(sniper, 6, 6, 9, 14, brass)
    rect(sniper, 6, 3, 9, 5, dark)
    rect(sniper, 7, 1, 8, 2, dark)
    rect(sniper, 6, 15, 9, 15, copper)
    write_png(os.path.join(ASSETS, "textures", "item", "sniper_ammo.png"), sniper)

    rocket = blank()
    rect(rocket, 6, 4, 9, 12, steel)
    rect(rocket, 7, 1, 8, 3, red)
    rect(rocket, 6, 3, 9, 3, red)
    rect(rocket, 3, 10, 5, 14, dark)
    rect(rocket, 10, 10, 12, 14, dark)
    rect(rocket, 6, 13, 9, 14, dark)
    write_png(os.path.join(ASSETS, "textures", "item", "rocket.png"), rocket)

    for n in ("rifle_ammo", "sniper_ammo", "rocket"):
        write_json(os.path.join(ASSETS, "models", "item", n + ".json"),
                   {"parent": "item/generated", "textures": {"layer0": "%s:item/%s" % (MOD, n)}})

    # 1-colour texture used by the custom entity renderers (tinted per vertex)
    write_png(os.path.join(ASSETS, "textures", "entity", "white.png"),
              [[(255, 255, 255, 255)] * 16 for _ in range(16)])


# ------------------------------------------------------------ lang + sounds
def build_lang_and_sounds():
    write_json(os.path.join(ASSETS, "lang", "en_us.json"), {
        "itemGroup.tacticalarms": "Tactical Arms",
        "item.tacticalarms.assault_rifle": "Assault Rifle",
        "item.tacticalarms.sniper_rifle": "Heavy Sniper Rifle",
        "item.tacticalarms.rocket_launcher": "Rocket Launcher",
        "item.tacticalarms.grenade": "HE Grenade",
        "item.tacticalarms.smoke_grenade": "Tactical Smoke Grenade",
        "item.tacticalarms.rifle_ammo": "Rifle Rounds",
        "item.tacticalarms.sniper_ammo": "Sniper Rounds",
        "item.tacticalarms.rocket": "Rocket",
        "entity.tacticalarms.bullet": "Bullet",
        "entity.tacticalarms.rocket": "Rocket",
        "entity.tacticalarms.he_grenade": "HE Grenade",
        "entity.tacticalarms.smoke_grenade": "Smoke Grenade",
    })

    def ev(event, pitch=1.0, volume=1.0):
        return {"sounds": [{"name": event, "type": "event", "pitch": pitch, "volume": volume}]}

    # Each custom sound event is an alias of a vanilla one: zero audio files required.
    # To use your own audio replace an entry with:  {"sounds": ["tacticalarms:rifle_shot"]}
    # and put assets/tacticalarms/sounds/rifle_shot.ogg (mono, 44.1 kHz) in place.
    write_json(os.path.join(ASSETS, "sounds.json"), {
        "rifle_shot": ev("minecraft:entity.firework_rocket.blast", 1.7, 0.9),
        "sniper_shot": ev("minecraft:entity.generic.explode", 1.9, 1.0),
        "rocket_launch": ev("minecraft:entity.firework_rocket.launch", 0.6, 1.0),
        "grenade_throw": ev("minecraft:entity.snowball.throw", 0.7, 1.0),
        "grenade_bounce": ev("minecraft:block.anvil.land", 1.9, 0.4),
        "smoke_pop": ev("minecraft:block.fire.extinguish", 0.6, 1.0),
        "gun_empty": ev("minecraft:block.dispenser.fail", 1.2, 0.8),
    })


# ------------------------------------------------------------------ recipes
def recipe(name, obj):
    write_json(os.path.join(DATA, "recipes", name + ".json"), obj)


def item(i):
    return {"item": i}


def build_recipes():
    iron, nug, gp, rs, lever = "minecraft:iron_ingot", "minecraft:iron_nugget", "minecraft:gunpowder", \
        "minecraft:redstone", "minecraft:lever"
    mk = lambda r: "%s:%s" % (MOD, r)

    recipe("assault_rifle", {
        "type": "minecraft:crafting_shaped", "category": "equipment",
        "pattern": ["III", "RLR", "I  "],
        "key": {"I": item(iron), "R": item(rs), "L": item(lever)},
        "result": item(mk("assault_rifle"))})
    recipe("sniper_rifle", {
        "type": "minecraft:crafting_shaped", "category": "equipment",
        "pattern": ["IIG", "RLI", "S  "],
        "key": {"I": item(iron), "G": item("minecraft:glass_pane"), "R": item(rs),
                "L": item(lever), "S": item("minecraft:stick")},
        "result": item(mk("sniper_rifle"))})
    recipe("rocket_launcher", {
        "type": "minecraft:crafting_shaped", "category": "equipment",
        "pattern": ["III", "LTI", "III"],
        "key": {"I": item(iron), "L": item(lever), "T": item("minecraft:tnt")},
        "result": item(mk("rocket_launcher"))})
    recipe("rifle_ammo", {
        "type": "minecraft:crafting_shapeless", "category": "equipment",
        "ingredients": [item(nug), item(nug), item(gp)],
        "result": {"item": mk("rifle_ammo"), "count": 8}})
    recipe("sniper_ammo", {
        "type": "minecraft:crafting_shapeless", "category": "equipment",
        "ingredients": [item(iron), item(gp), item(gp)],
        "result": {"item": mk("sniper_ammo"), "count": 4}})
    recipe("rocket", {
        "type": "minecraft:crafting_shapeless", "category": "equipment",
        "ingredients": [item("minecraft:tnt"), item(iron), item(gp), item(gp)],
        "result": {"item": mk("rocket"), "count": 2}})
    recipe("grenade", {
        "type": "minecraft:crafting_shaped", "category": "equipment",
        "pattern": [" N ", "IGI", " I "],
        "key": {"N": item(nug), "I": item(iron), "G": item(gp)},
        "result": {"item": mk("grenade"), "count": 2}})
    recipe("smoke_grenade", {
        "type": "minecraft:crafting_shaped", "category": "equipment",
        "pattern": [" N ", "ICI", " I "],
        "key": {"N": item(nug), "I": item(iron), "C": {"tag": "minecraft:coals"}},
        "result": {"item": mk("smoke_grenade"), "count": 2}})


if __name__ == "__main__":
    build_models()
    build_ammo()
    build_lang_and_sounds()
    build_recipes()
    print("assets generated under", os.path.normpath(ASSETS))
