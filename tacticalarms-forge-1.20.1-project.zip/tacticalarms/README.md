# Tactical Arms — lightweight weapons mod (Minecraft 1.20.1, Forge 47.x)

> **Version note:** Minecraft 1.20.1 uses Forge **47.x** (this project targets 47.4.0).
> "Forge 26.3" is not a version that exists for 1.20.1. Any Forge 47.x build works.

## Features
| Item | Behaviour |
|---|---|
| Assault Rifle | Hold right-click = full-auto (10 shots/s), uses Rifle Rounds, recoil kick, tracer bullets |
| Heavy Sniper Rifle | One shot per 2 s, 22 dmg (headshot x2), 9 blocks/tick bullet. Crouch = 4x zoom + zero spread |
| Rocket Launcher | Explosive rocket, smoke + flame trail, back-blast, big recoil |
| HE Grenade | Bounces, explodes after 3 s |
| Tactical Smoke Grenade | Pops after ~1 s, 10 s smoke cloud, mobs in the cloud lose their target |

Everything is in the **Tactical Arms** creative tab and has a crafting recipe.
Configuration: `config/tacticalarms-common.toml` (damage, explosion power, block damage on/off, smoke density).

## Build the .jar (PC: Windows / Linux / macOS)
1. Install **JDK 17** (e.g. Temurin 17) and check `java -version` shows 17.
2. Open a terminal in this folder.
3. Run:
   - Windows: `gradlew.bat build`
   - Linux/macOS: `chmod +x gradlew && ./gradlew build`
4. First run downloads Forge + Minecraft (about 5–15 min). Needs internet.
5. Your mod is at `build/libs/tacticalarms-1.0.0.jar`.

### Alternative: IntelliJ IDEA
File > Open > select `build.gradle` > "Open as Project", wait for Gradle sync, then Gradle panel > `Tasks > build > build`.

### If Gradle complains
- "Unsupported class file / Java version": Gradle is using the wrong JDK. Set JAVA_HOME to JDK 17.
- Plugin not found: your network blocks `maven.minecraftforge.net`; use a VPN or different network.
- Prefer the official MDK? Download the 1.20.1 MDK from files.minecraftforge.net, copy this project's
  `src/` folder over the MDK's `src/`, set `mod_id=tacticalarms` in its `gradle.properties`, and run `gradlew build`.

## Install on Android (Mojo Launcher or any launcher that runs Forge 1.20.1)
1. Install Minecraft 1.20.1 **with Forge 47.x** through the launcher.
2. Copy `tacticalarms-1.0.0.jar` into the instance's `mods` folder.
3. Launch the Forge profile. The "Tactical Arms" creative tab should appear.

I could not test on Mojo here, so check your launcher's Forge 1.20.1 support first.

## Performance design (mobile friendly)
- No dependencies, no custom shaders, no block entities, no per-tick world scans except the smoke cloud (every 10 ticks, 4-block box).
- Bullets: no gravity, short lifetime, rendered as 8 vertices. Rockets: 24 quads. Grenades use their small item models.
- Particle budgets are fixed: 1 smoke + 1 flame per rifle shot; smoke grenade = 3 particles / 4 ticks (configurable, set `smokeParticlesPerBurst = 0` to disable).
- Entity update intervals are slow because clients simulate projectile movement.
- Resting grenades switch off gravity so they stop colliding every tick.

## Customising
- **Models:** edit the `ASSAULT`/`SNIPER`/`ROCKET`/`GRENADE`/`SMOKE` tables in `tools/gen_assets.py`, then run `python3 tools/gen_assets.py`.
  Or open `assets/tacticalarms/models/item/*.json` in Blockbench. If a gun looks mis-positioned in your hand, tweak the
  `firstperson_righthand` / `thirdperson_righthand` translation in that JSON.
- **Textures:** replace the PNGs in `assets/tacticalarms/textures/item/` (keep names).
- **Sounds:** every custom sound event (`rifle_shot`, `sniper_shot`, ...) aliases a vanilla sound in `sounds.json`.
  For your own audio, put `rifle_shot.ogg` in `assets/tacticalarms/sounds/` and change the entry to
  `"rifle_shot": { "sounds": ["tacticalarms:rifle_shot"] }`.

## Project layout
```
src/main/java/com/tacticalarms/
  ModMain.java        entry point
  ModItems / ModEntities / ModSounds / ModTabs / ArmsConfig
  item/               GunItem (ammo, recoil, fx), AssaultRifleItem, SniperRifleItem, RocketLauncherItem, GrenadeItem
  entity/             BulletEntity, RocketEntity, AbstractGrenadeEntity, HeGrenadeEntity, SmokeGrenadeEntity, Explosions
  client/             ClientSetup (renderer registration), BulletRenderer, RocketRenderer, ClientEvents (zoom), ClientHooks (recoil)
  network/            Network, RecoilPacket
```

## Build without installing anything (GitHub Actions)
1. Create a free GitHub account and a new repository.
2. Upload ALL files of this project (including the hidden `.github` folder).
3. Open the repo's **Actions** tab. The "Build mod jar" workflow starts by itself (or press "Run workflow").
4. When it turns green, open the run and download **tacticalarms-jar** under "Artifacts". Unzip it: the .jar inside is your mod.
